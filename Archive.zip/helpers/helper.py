from datetime import datetime

def parse_datetime(dt_str):
    return datetime.strptime(dt_str, "%Y-%m-%d %H:%M")

def is_overlap(existing_start, existing_end, new_start, new_end):
    return not (new_end <= existing_start or new_start >= existing_end)