import json

from flask import Flask, request
from service import service 

app = Flask(__name__)

DEFAULT_STATUS_CODE = "failure"
SUCCESS_STATUS_CODE = "success"

@app.route('/')
def greet():
    return 'Welcome to Python Assignment'

@app.route('/assignment/bookings', methods=['GET'])
def handle_request():
    """
    API endpoint for fetching all bookings
    """
    response = prepare_result_container()
    try:
        response["response"] = service.fetch_all_bookings()
        response["status"] = SUCCESS_STATUS_CODE
    except Exception as error:
        response["error"] = str(error)
        return json.dumps(response)
    else:
        return json.dumps(response)

@app.route("/available-halls", methods = ["POST"])
def available_halls():
    print("controller is called")
    request_data = {
    "0": {
        "capacity": 50,
        "startTime": "2020-12-27 15:00:00",
        "endTime": "2020-12-27 16:00:00"
    },
    "1": {
        "capacity": 1000,
        "startTime": "2020-12-27 15:00:00",
        "endTime": "2020-12-27 17:00:00"
    }
}

    if not isinstance(request_data, dict):
        return ({"error": "Input must be an object of objects" })
    
    response = {}

    for key, item in request_data.items():
        required_fields = ["start_time", "end_time", "capacity"]
        if not all(field in item for field in required_fields):
            response[key] = []
            continue

        halls = service.get_available_halls(
            item["start_time"],
            item["end_time"],
            item["capacity"]
        )
        response[key] = halls
    return {
        "status": "success",
        "data": response
    }


def prepare_result_container():
    """
    Returns a dict - response
    """
    return {
        "response":{},
        "status":DEFAULT_STATUS_CODE,
        "error": ""
    }
