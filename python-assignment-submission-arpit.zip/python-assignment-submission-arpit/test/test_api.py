import requests
from pprint import pprint
data = {
    "0": {
        "capacity": 50,
        "startTime": "2020-12-27 15:00:00",
        "endTime": "2020-12-27 16:00:00"
    },
    "1": {
        "capacity": 1000,
        "startTime": "2020-12-27 15:00:00",
        "endTime": "2020-12-27 17:00:00"
    }
}
def get_all_bookings():
    """
    Creates a request to fetch all bookings
    """
    response = requests.post("http://localhost:8085/available-halls", data = data)
    pprint(response.text)

if __name__ == '__main__':
    get_all_bookings()


