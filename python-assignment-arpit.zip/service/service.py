from repository import query_database
from helpers import helper

HALLS = {
    "A": 50,
    "B": 100,
    "C": 200,
    "D": 350,
    "E": 500,
    "F": 1000

}

def fetch_all_bookings():
    """
    Fetches all booking from the database table 'BOOKING'
    """
    client = query_database.DB_Client()
    bookings = client.fetch_bookings("SELECT * FROM BOOKING")
    return bookings

def get_available_halls(start_time, end_time, capacity_required):
    new_start = helper.parse_datetime(start_time)
    new_end = helper.parse_datetime(end_time)
    
    if new_start >= new_end:
        return []
    
    eligible_halls = [
        hall for hall, capacity in HALLS.item()
        if capacity >= capacity_required
    ]

    available_halls = []

    for hall in eligible_halls:
        bookings = """SELECT start_time, end_time FROM BOOKING where hall_id = ?"""
        conflict = False

        for booking in bookings:
            existing_start = helper.parse_datetime(booking["start_time"])
            existing_end = helper.parse_datetime(booking["end_time"])

            if helper.is_overlap(existing_start, existing_end, new_start, new_end):
                conflict = True
                break
            
        if not conflict:
            available_halls.append(hall)
    return available_halls
